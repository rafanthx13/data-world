# Time series

### Dict English

+ forecasting = previsão
+ lags = períodos
+ weather = tempo

## Links vistos

+ https://medium.com/data-hackers/series-temporais-parte-1-a0e75a512e72 [X]
+ [https://medium.com/techbloghotmart/o-que-s%C3%A3o-s%C3%A9ries-temporais-e-como-aplicar-em-machine-learning-6ea5d94bec78](https://medium.com/techbloghotmart/o-que-são-séries-temporais-e-como-aplicar-em-machine-learning-6ea5d94bec78) [X]

## O que é Series temporais

Uma série temporal é um conjunto de observações feitas em sequência ao longo do tempo. Em séries temporais a ordem dos dados é fundamental.

As observações vizinhas são relacionadas. Por exemplo, a quantidade de carros vendidos em dezembro pode estar relacionada à quantidade de carros vendidos em novembro ou até mesmo relacionada com a de setembro.

Além disso, séries temporais são processos estocásticos por leis probabilisticas — que significa que pode ser pensando como um conjunto de todas as possíveis trajetórias(FIGURA 1) que poderiam ser observadas para uma variável alvo. Por exemplo, se você jogar um dado pode ser qualquer valor inteiro entre 1 e 6, mas apenas um número vai ocorrer . Da mesma forma, nas séries temporais existem infinitas possibilidades, dentre elas apenas uma de acordo com as características que estavam presentes naquele período e que de fato vai ocorrer.

![](/home/rhavel/Documentos/Personal Projects/time-series-study/my-notes/imgs/img-001.png)

**Objetivos**

Um dos objetivos da série temporal é compreender a estrutura da série, o que é de grande importância pois podemos, por exemplo, tentar entender se existe alguma tendência de crescimento de vendas de um determinado produto, entender como esse produto está comportando e poder tomar decisões a partir de insights gerados com a análise dos dados. Um bom exemplo são os panetones, mais demandados em dezembro . Assim, sabendo que um produto pode ter maior demanda em um determinado mês, uma empresa pode preparar a infraestrutura para ter maior venda deste produto.

Além disso, o estudo dessas séries também é relevante porque pode proporcionar a realização de previsões de valores futuros da série , ou seja, o que vai acontecer lá no futuro. Por exemplo, prever como vai ser a venda de um produto, e responder a perguntas como: será que vai ter um crescimento maior? um crescimento menor? permanecerá estável?. A partir disso, pode-se ter uma maior preparação também.

**Aplicações**

Séries temporais estão presentes na nossa vida de várias formas em vários lugares. É incrível!

- Economia: Preços diários de ações, taxa mensal de desemprego;
- Saúde: Número mensal de novos casos de alguma doença,registro de um eletrocardiograma de uma pessoa;
- Climatologia: Temperatura diária;
- Marketing: Previsão de aquisição de novos clientes, previsão de volume de viagens;
- Administrativo: Previsão de vendas de produtos;

Esses são só alguns exemplos, séries temporais estão presentes em diversas áreas e a partir delas podemos entender mais os dados que as compõem e tomar decisões mais assertivas.

## Divisão em train/test para time-series

Diferente de outros métodos de previsões, como classificações e regressões sem a influência do tempo, em séries temporais não podemos dividir os dados de treino e teste com amostras aleatórias de qualquer parte dos dados, deve-se seguir o critério temporal da série, onde os dados de treino devem vir antes dos dados de teste.

Neste exemplo dos preços do Hidratado temos 856 semanas, onde usaremos como base de treino as primeiras 700 semanas e as últimas 156 semanas (3 anos ~18%) usaremos como base de testes

## Principios para prever numa série temporal - Estacionaridade

[https://medium.com/ensina-ai/princ%C3%ADpios-b%C3%A1sicos-para-criar-previs%C3%B5es-de-s%C3%A9ries-temporais-e58c451a25b](https://medium.com/ensina-ai/princípios-básicos-para-criar-previsões-de-séries-temporais-e58c451a25b)

Analisar séries temporais são úteis para verificar esses padrões e criar previsões de movimentos futuros.

git

https://nbviewer.jupyter.org/github/leandrovrabelo/tsmodels/blob/master/notebooks/portugues/Princi%CC%81pios%20Ba%CC%81sicos%20para%20Prever%20Se%CC%81ries%20Temporais.ipynb

**Série estacionária**

Uma série estacionária tem média constante durante o tempo, não existe tendências de alta ou de baixa. A razão disso é que tendo uma média constante com variações ao redor desta média fica muito mais fácil de extrapolar ao futuro.

Uma série temporal estacionária é aquela cujas propriedades estatísticas, como a média, a variância e a auto correlação, são constantes ao longo do tempo. Assim, uma série não estacionária é uma cujas propriedades estatísticas mudam com o tempo.

Antes de iniciar qualquer modelagem preditiva é necessário verificar se essas propriedades estatísticas são constantes, abaixo explicarei cada um desses pontos:

- Média constante

- Com variância constante

- Auto correlacionada: 

  - Quando duas variáveis tem variação semelhante em relação ao desvio padrão pode-se dizer que as variáveis são correlacionadas, um exemplo seria o aumento do peso corporal com doenças do coração, quanto maior o peso maior a incidência de problemas no coração, neste caso a correlação é positiva

  - Quando o assunto é **Auto Correlação**, significa que existe uma correlação de determinados períodos anteriores com o período atual, o nome que se dá ao período com esta correlação é **lag**, exemplo: em uma série que tem medições a cada hora, a temperatura de hoje às 12:00h é muito semelhante à temperatura de 24 horas atrás, neste caso há uma auto correlação dos valores atuais com o 24º lag.

  - Existir auto correlação é condição para se criar previsões com uma única variável, pois caso não exista essa correlação não pode-se usar valores passados para prever o futuro, quando existem diversas variáveis, pode-se verificar se há correlação entre a variável dependente e os lags das variáveis independentes.

    Caso uma série não tenha auto correlação ela é uma série com sequências aleatória e imprevisíveis e a melhor maneira de se fazer uma previsão normalmente é usar o valor do dia anterior. 

---

[http://www.bertolo.pro.br/MetodosQuantitativos/Previsao/pmc442.htm#:~:text=Uma%20suposi%C3%A7%C3%A3o%20comum%20em%20muitas,mudam%20no%20decorrer%20do%20tempo.](http://www.bertolo.pro.br/MetodosQuantitativos/Previsao/pmc442.htm#:~:text=Uma suposição comum em muitas,mudam no decorrer do tempo.)

Um processo estacionário tem a propriedade de que a média, variância e estrutura de autocorrelação não mudam no decorrer do tempo. Estacionariedade pode ser definida em termos matemáticos precisos, mas para os nossos propósitos queremos dizer uma série parecida com um plano liso, sem tendência, variância constante no decorrer do tempo, um estrutura de autocorrelação constante no decorrer do tempo e nenhuma flutuação periódica

**SE NAO FOR ESTACIONARIA**??

Se a série temporal não for estacionária, podemos frequentemente transformá-la em estacionária com uma das técnicas seguintes.

1. Podemos diferenciar os dados. Isto é, dada a série *Zt*, criamos a nova série


   Os dados diferenciados conterão um ponto a menos que os dados originais. Embora você possa diferenciar os dados mais que uma vez, uma diferenciação é geralmente suficiente.

   

2. Se os dados tiverem uma tendência, podemos ajustar algum tipo de curva aos dados e depois então modelar os resíduos daquele ajuste. Desde que o propósito do ajuste é simplesmente remover tendências de longo prazo, um ajuste simples, tal como uma linha reta, é tipicamente usado.

   

3. Parta variância não constante, tomando o logarítmo ou a raiz quadrada da série pode estabilizar a variância. Para dados negativos, você pode adicionar uma constante adequada para tornar todos os dados positivos antes de aplicar a transformação. Esta constante pode então ser subtraída do modelo para obter valores previstos (i.e., ajustados) e previsões para pontos futuros.*

## Propriedades de uma Série temporal

### Tendência

Tendência: Significa saber se uma determinada série está crescendo, diminuindo ou se está estável. Na **Figura 2** a gente consegue observar um aumento na tendência. Por que isso se torna importante? Porque podemos saber qual será a tendência a curto, médio ou longo prazo dessa série temporal. Por exemplo, ter o conhecimento se o número de casos de uma doença vai aumentar, diminuir ou permanecer estável uma cidade é importante para o planejamento urbano.

![](/home/rhavel/Documentos/Personal Projects/time-series-study/my-notes/imgs/img-002.png)

### Sazionalidade

Sazonalidade: São flutuações periódicas, fenômenos que se repetem a cada período idêntico do tempo. Por exemplo, a venda dos panetones que aumentam durante os meses de dezembro, mas não apenas de um ano, mas do ano passado, do ano retrasado e assim por diante. Outros exemplos são os produtos que tendem a aumentar no verão como os biquínis ou os casacos no inverno, indicando, dessa forma um fenômeno sazonal. Na **Figura 3,** podemos observar o fenômeno de sazonalidade, em que ocorrem picos periódicos segundo a imagem;

![](/home/rhavel/Documentos/Personal Projects/time-series-study/my-notes/imgs/img-003.png)

### Ciclos

- É um aumento ou redução da frequência, mas sem intervalos fixos, o que difere da sazonalidade por não ter um intervalo frequente. Segundo a **Figura 4,** observa-se que não há intervalos fixos — há uma desregularidade.

Figura 4: Ciclos de uma Série Temporal

![](/home/rhavel/Documentos/Personal Projects/time-series-study/my-notes/imgs/img-004.png)

### Erro Aleatório

São flutuações inexplicáveis, resultando de fatos fortuitos e inesperados como catastrofes naturais, atentados terroristas e pandemias.

### Estacionariedade

Uma série estacionária é quando a média, variância e a estrutura de autocorrelação se mantém constantes durante o tempo. Na **Figura 5** podemos observar este fenomeno em que há estacionariedade na imagem, uma vez que a média permanece constante, enquanto na **Figura 6** observamos que a média não se mantém constante (ela tende a crescer).

Figura 5: Série Estacionária com média constante

![](/home/rhavel/Documentos/Personal Projects/time-series-study/my-notes/imgs/img-005.png)

Figura 6 Série não Estacionária com a média não constante



![](/home/rhavel/Documentos/Personal Projects/time-series-study/my-notes/imgs/img-006.png)

Para conseguir saber se uma série é estacionária, podemos realizar alguns testes estatísticos como Dickey-Fuller, Kpss, Philips perron.

### Resíduos

que é o que resta após retirar da série as duas primeiras partes, abaixo a separação dessas partes:

[https://medium.com/ensina-ai/princ%C3%ADpios-b%C3%A1sicos-para-criar-previs%C3%B5es-de-s%C3%A9ries-temporais-e58c451a25b](https://medium.com/ensina-ai/princípios-básicos-para-criar-previsões-de-séries-temporais-e58c451a25b)

## Outras funçêos matemáticas

### **Funções ACF (Auto-Correlation Function) e PACF (partial auto-correlation function)**

Para saber quantos termos utilizar no treino de seu modelo, você irá fazer uso de duas funções muito úteis: a Função de Autocorrelação (ACF) e a Função de Autocorrelação Parcial (PACF). Ao utilizá-las em seu código, você irá visualizar dois gráficos semelhantes ao abaixo:

![](/home/rhavel/Documentos/Personal Projects/time-series-study/my-notes/imgs/img-010.png)

Esse gráfico, chamado de gráfico de pirulito (do inglês lollipop chart) nos mostra a quantidade de termos que precisaremos informar. Existem diferentes formas de interpretá-lo, onde uma das mais utilizadas é a seguinte:

**Quantidade de termos em p**

Ambos os gráficos terão o primeiro pirulito com valor 1. Para saber o quanto de termos AR irá precisar, **olhe para o gráfico de ACF (parte superior da imagem acima) e veja se o segundo lollipop caiu exponencialmente**. Se caiu, **olhe para o gŕafico de PACF (parte inferior da imagem acima) e conte quantos pirulitos passam o valor crítico (faixa azulada horizontal) antes de retornarem para dentro da faixa**. No caso da nossa imagem acima, nosso p teria oito termos.

**Quantidade de termos em q**

Um processo muito semelhante é feito para saber a quantidade de termos q. **Olhe para o gráfico de PACF (parte superior da imagem acima) e veja se o segundo lollipop caiu exponencialmente**. Se caiu, **olhe para o gŕafico de ACF (parte inferior da imagem acima) e conte quantos pirulitos passam o valor crítico (faixa azulada horizontal) antes de retornarem para dentro da faixa**. No caso da nossa imagem acima, nosso q teria cinco termos.

----



## Testes Estatísticos

### Teste de Dickey-Fuller **ADF**

[https://medium.com/techbloghotmart/o-que-s%C3%A3o-s%C3%A9ries-temporais-e-como-aplicar-em-machine-learning-6ea5d94bec78](https://medium.com/techbloghotmart/o-que-são-séries-temporais-e-como-aplicar-em-machine-learning-6ea5d94bec78)

Resumidamente, esse teste é capaz de nos dizer se a nossa série é estacionária ou não. Vamos imaginar que depois de registrar todos os dias em que vendeu picolé, a distribuição dos seus dados fica assim.

![](/home/rhavel/Documentos/Personal Projects/time-series-study/my-notes/imgs/img-008.png)



Após o teste ser rodado, você receberá um resultado semelhante ao que vê acima. Preste atenção às seguintes informações:

Perceba que há três valores críticos — Critical Value — no fim da tabela: 10%, 5%, 1%. Nosso principal interesse é fazer com que o valor do Teste Estatístico (-0.803967) seja menor que o valor crítico de 1%. Caso isso aconteça, nós podemos dizer que nossa série é estacionária. Segundo o resultado do teste, a sua série temporal de venda de picolé não é estacionária.



### Teste KPSS

Agora vamos analisar a série com o teste **KPSS**, ao contrário do teste de Dickey Fuller, o teste KPSS já pressupõe que a série é estacionária e só não será se o valor P for inferior a 5% ou o teste estatístico for menor que algum valor crítico escolhido

## COMO TORNAR EM ESTACIONÁRIA

Mas, e aí? O que fazemos agora? Sua time series não é estacionária, isso quer dizer que não podemos prever valores futuros para ela? Felizmente, podemos sim. Existem algumas técnicas que podem ser utilizadas para transformar uma série não-estacionária em uma série estacionária.

Não vou entrar em detalhes muito profundos, mas, basicamente, as técnicas mais utilizadas para transformação de uma série são:

- Calcular a **raiz quadrada** de todas as observações da série temporal
- Calcular a **raiz cúbica** de todas as observações da série temporal
- Calcular o **log** de todas as observações da série temporal
- Calcular a **primeira diferença** de todas as observações da série temporal

Tirar a **primeira diferença** — do inglês First Difference — é bem simples: basta subtrair o valor de uma observação por um valor defasado. Por exemplo: subtrair o valor de hoje pelo valor de ontem, ou pelo valor de sete dias atrás, e por aí vai.

Para cada uma das transformações que você fizer, será necessário realizar o teste de Dickey-Fuller novamente e acompanhar os resultados. Para saber mais a fundo sobre como funciona as técnicas de transformação, [visite o site da Universidade Duke](http://goo.gl/iSSte3).

Em nosso exemplo, eu vou inicialmente tirar o log das observações e realizar o teste estatístico de novo:

![](/home/rhavel/Documentos/Personal Projects/time-series-study/my-notes/imgs/img-009.png)

Parece que a nossa transformação teve bons resultados. Agora nosso Teste Estatístico (-4.626151) teve um valor menor que o valor crítico de 1% (-3.518281). Agora sim nossa série está estacionária e pronta para previsão!

## Modelos de TimeSeries

### AR - Auto Regression

O modelo Auto-regressivo (AR) — utiliza a própria variável alvo para projetá-la a partir da variável no passado;

Uma série temporal segue um processo auto-regressivo quando o valor da série no tempo t depende do que aconteceu em, por exemplo, t-1, t-2, t-3, t-4, etc.

Um bom exemplo de uma equação que representa os modelos auto-regressivos é a seguinte (não coloquei as nomenclaturas matemáticas a fim de ter uma linguagem mais acessível):

**Yt = 23.15+0.98\*(yt-1)+0.45\*(yt-2)**

Y= Valor previsto

yt-1 = Valor da série no instante t-1

yt-2 = Valor da série no instante t-2

Nessa equação temos um exemplo de modelo auto-regressivo de ordem 2 (AR(2). Isso significa que são necessárias duas defasagens para projetar o próximo mês, caso queira prever como séria, por exemplo, a demanda de um produto no próximo mês.

**Resumindo**: Se quero saber um valor do futuro basta então pegar um ou dois valores de momentos anteriores e assim utilizá-los para prever, assim tenho uma Auto Regressão

### ARMA - Auto Regressive Moving Average 

Soma de AR + MA

+ Apresenta-se Auto-regressivo (AR), ou seja,utiliza a própria variável alvo para projetá-la a partir da variável no passado. 

+ Apresenta também média Móvel (MA), uma vez que utiliza os erros anteriores para realizar a previsão;

Exemplo

```
Erros = previsto — real(em módulo).
Yt = 23.15+0.98*(yt-1)+0.45*(et-1)
Y= Valor previsto
yt-1 = Valor da série no instante t-1
et-1 = Erro anterior no instante t-1

Nesta equação temos um exemplo de modelo auto-regressivo de média móvel, pois utilizamos uma variável com valor da série no instante t-1 e uma variável com o erro anterior no instante t-1. Portanto, temos uma ARMA(1,1), ou seja, p = 1 e q =1 , modelo auto -regressivo de média móvel de ordem 1.
```

### ARIMA - Auto Regressive Integrated Moving Average

 o ARIMA utiliza dados passados para prever o futuro, usando dois principais recursos: a autocorrelação e médias móveis. Além disso, ARIMA possui algumas vertentes, como modelos que permitem identificar e considerar a sazonalidade (SARIMA), modelos AR, MA, ARMA e por aí vai.

Todo modelo preditivo possui suas próprias características e, consequentemente, seus próprios parâmetros. Árvores de Decisão possuem parâmetros diferentes de uma Regressão Linear, por exemplo, como tamanho das folhas e nós. Assim é com o ARIMA também, ele possui seus próprios parâmetros (que no campo de séries temporais são chamados de “termos”), que serão utilizados para afiar o seu modelo. Nesse post, irei dar ênfase em três principais:, p, d e q.

Cada letra de p, d e q representam uma parte da sigla ARIMA. Como pode ver abaixo, o “p” está para o “AR” do nome do modelo, enquanto “d” está para “I” e, por fim, “q” está para “MA”

![](/home/rhavel/Documentos/Personal Projects/time-series-study/my-notes/imgs/img-007.png)

Quando você está construindo o modelo, você irá passar esses parâmetros na forma de uma tupla, sendo que p, d e q são números inteiros. Alguns exemplos de parâmetros que você passa na hora de criar seu modelo são: (1, 1, 1), (2,0,1), (0,0,1), e etc.

**curiosidade**

Lembra que falei que cada letra representa uma parte do ARIMA? Se você passa esses três parâmetros sem incluir um deles (ao colocar o número 0), você tem um tipo de modelo diferente. Por exemplo, se você passa os parâmetros (0, 0, 1), você não terá mais um modelo ARIMA, e sim um modelo MA; se você utiliza (1,0,0), você terá um modelo AR; se usar (1,0,1), você criou um modelo ARMA. Bem legal, né?

---

A ARIMA exige um parâmetro a mais, que é **q** que são os números de vezes que ocorrem as transformações. Então, por exemplo, realizou- se duas diferenciações para que a série se torne estacionária, portanto d = 2.

This acronym is descriptive, capturing the key aspects of the model itself. Briefly, they are:

- **AR**: *Autoregression*. A model that uses the dependent relationship between an observation and some number of lagged observations.
- **I**: *Integrated*. The use of differencing of raw observations (e.g. subtracting an observation from an observation at the previous time step) in order to make the time series stationary.
- **MA**: *Moving Average*. A model that uses the dependency between an observation and a residual error from a moving average model applied to lagged observations.

Each of these components are explicitly specified in the model as a parameter. A standard notation is used of ARIMA(p,d,q) where the parameters are substituted with integer values to quickly indicate the specific ARIMA model being used.

The parameters of the ARIMA model are defined as follows:

- **p**: The number of lag observations included in the model, also called the lag order.
- **d**: The number of times that the raw observations are differenced, also called the degree of differencing.
- **q**: The size of the moving average window, also called the order of moving average.

### SARIMA - Seasonal Autoregressive Integrated Moving Average

[https://medium.com/techbloghotmart/dicas-para-criar-um-modelo-de-previs%C3%A3o-de-s%C3%A9ries-temporais-d4bb2e32e148](https://medium.com/techbloghotmart/dicas-para-criar-um-modelo-de-previsão-de-séries-temporais-d4bb2e32e148)

The notation for the model involves specifying the order for the AR(p), I(d), and MA(q) models as parameters to an ARIMA function and AR(P), I(D), MA(Q) and m parameters at the seasonal level, e.g. SARIMA(p, d, q)(P, D, Q)m where “m” is the number of time steps in each season (the seasonal period). A SARIMA model can be used to develop AR, MA, ARMA and ARIMA models.

----



A sigla SARIMA tem o mesmo significado que ARIMA, onde o “S” representa a sazonalidade. Seu processo de construção é exatamente o mesmo que mostramos anteriormente, onde você terá que verificar se sua série é estacionária, usar as funções ACF e PACF para ver a quantidade de termos e etc. Sua principal diferença está no momento de treinar o modelo, onde você usará uma nova função e irá adicionar mais um argumento.

![](/home/rhavel/Documentos/Personal Projects/time-series-study/my-notes/imgs/img-011.png)

![](/home/rhavel/Documentos/Personal Projects/time-series-study/my-notes/imgs/img-006.png)

Perceba que agora utilizamos a função SARIMAX e passamos o parâmetro “seasonal_order”, onde definimos os parâmetros P, D e Q para a sazonalidade. O número “7” que você vê no final do parâmetro é o número de periodicidade em uma temporada. Geralmente é “7” para dados diárias, “12” para dados mensais, e por aí vai.

### Seasonal Autoregressive Integrated Moving-Average with Exogenous Regressors (SARIMAX)

Finally the **X**, from *exogenous* variables, which basically allows external variables to be considered in the model, such as weather forecasts.

### Vector Autoregression (VAR)

The Vector Autoregression (VAR) method models the next step in each time series using an AR model. It is the generalization of AR to multiple parallel time series, e.g. multivariate time series.

The notation for the model involves specifying the order for the AR(p) model as parameters to a VAR function, e.g. VAR(p).

```python
from statsmodels.tsa.vector_ar.var_model import VAR
from random import random
# contrived dataset with dependency
data = list(...)
# fit model
model = VAR(data)
model_fit = model.fit()
# make prediction
yhat = model_fit.forecast(model_fit.y, steps=1)
print(yhat)
```



### Vector Autoregression Moving-Average (VARMA)

The Vector Autoregression Moving-Average (VARMA) method models the next step in each time series using an ARMA model. It is the generalization of ARMA to multiple parallel time series, e.g. multivariate time series.

The notation for the model involves specifying the order for the AR(p) and MA(q) models as parameters to a VARMA function, e.g. VARMA(p, q). A VARMA model can also be used to develop VAR or VMA models.

```python
# VARMA example
from statsmodels.tsa.statespace.varmax import VARMAX
from random import random
# contrived dataset with dependency
data = list()
for i in range(100):
    v1 = random()
    v2 = v1 + random()
    row = [v1, v2]
    data.append(row)
# fit model
model = VARMAX(data, order=(1, 1))
model_fit = model.fit(disp=False)
# make prediction
yhat = model_fit.forecast()
print(yhat)
```



### Vector Autoregression Moving-Average with Exogenous Regressors (VARMAX)

The Vector Autoregression Moving-Average with Exogenous Regressors (VARMAX) is an extension of the VARMA model that also includes the modeling of exogenous variables. It is a multivariate version of the ARMAX method.

Exogenous variables are also called covariates and can be thought of as parallel input sequences that have observations at the same time steps as the original series. The primary series(es) are referred to as endogenous data to contrast it from the exogenous sequence(s). The observations for exogenous variables are included in the model directly at each time step and are not modeled in the same way as the primary endogenous sequence (e.g. as an AR, MA, etc. process).

The VARMAX method can also be used to model the subsumed models with exogenous variables, such as VARX and VMAX.

The method is suitable for multivariate time series without trend and seasonal components with exogenous variables.

```python
# VARMAX example
from statsmodels.tsa.statespace.varmax import VARMAX
from random import random
# contrived dataset with dependency
data = list()
for i in range(100):
    v1 = random()
    v2 = v1 + random()
    row = [v1, v2]
    data.append(row)
data_exog = [x + random() for x in range(100)]
# fit model
model = VARMAX(data, exog=data_exog, order=(1, 1))
model_fit = model.fit(disp=False)
# make prediction
data_exog2 = [[100]]
yhat = model_fit.forecast(exog=data_exog2)
print(yhat)
```



### Simple Exponential Smoothing (SES)

The Simple Exponential Smoothing (SES) method models the next time step as an exponentially weighted linear function of observations at prior time steps.

The method is suitable for univariate time series without trend and seasonal components.

```python
# SES example
from statsmodels.tsa.holtwinters import SimpleExpSmoothing
from random import random
# contrived dataset
data = [x + random() for x in range(1, 100)]
# fit model
model = SimpleExpSmoothing(data)
model_fit = model.fit()
# make prediction
yhat = model_fit.predict(len(data), len(data))
print(yhat)
```



### Holt Winter’s Exponential Smoothing (HWES)

The [Holt Winter’s Exponential Smoothing](https://machinelearningmastery.com/how-to-grid-search-triple-exponential-smoothing-for-time-series-forecasting-in-python/) (HWES) also called the Triple Exponential Smoothing method models the next time step as an exponentially weighted linear function of observations at prior time steps, taking trends and seasonality into account.

The method is suitable for univariate time series with trend and/or seasonal components.

```python
# HWES example
from statsmodels.tsa.holtwinters import ExponentialSmoothing
from random import random
# contrived dataset
data = [x + random() for x in range(1, 100)]
# fit model
model = ExponentialSmoothing(data)
model_fit = model.fit()
# make prediction
yhat = model_fit.predict(len(data), len(data))
print(yhat)
```

