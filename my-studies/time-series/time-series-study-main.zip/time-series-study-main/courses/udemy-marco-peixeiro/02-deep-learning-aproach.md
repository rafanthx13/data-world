# TS - Deep Learning Aproach

Há 3 principais arquiteturas

+ DNN
  - Rede Neural Densa (várias camadas). O mais simples
+ RNN+LSTM
  - Recurrent Neural Network with Long-Shot Term memory
  - Para dadaos sequenciais onde o futuro depende do passado, como uma TIme Series real é
+ CNN+RNN
  - Com CNN sobre a RNN podmeo melhorar bastante nossos modelos

## DNN

Não há pre-processamento; 

Na DNN As entradas são consideradas independentes, o que pode nâo acontecer em todoas as TS

## RNN+LSTM

A RNN tem uma memória interea para processar uma sequência de entradas.

EM RNN a entrada é a própria row e a saida da row anterior.

A LSTM é uma mehloria na RNN qu e permite relembrar coisa mais antigas e esquecer algumas informaçôes que podem ser inúteis

(link0)[https://towardsdatascience.com/illustrated-guide-to-lstms-and-gru-s-a-step-by-step-explanation-44e9eb85bf21]

## CNN

Usada mais em visual computacional.

O prinpal dessa arquitetura é a convoluçâo, que é um mapeamento dos dados para uma forma menor através de um filtro que é uma função

Padding: Adicionar borda sobre os dados apos as convoluçôes, pois o tamanho da matriz fica menor.

Porque usamos CNN em TS: Para filtrar uma TImeSeries: remover ruido e manters os dados mais importantes da série
