# Phophet

Lib do Facebbok para automatizar operaçoes de forecast.

Ele é totalmente atumático, entâo, você tem um modelo pronto em poucos minutos.

É capaz de lidar com: falta de tendencia, falta de dados; outliers; mudança de tendencias e feriados, o que nos torna mais produtivo por evitra pré-processamento

é rápido e tunável

Funciona bem em vários dados e bom para TS sazionais.

Ele pode ser bom, mas não é o melhor modelo.
