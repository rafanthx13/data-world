# Intro Time Series

## Referencias do INstrutor

The following resources were used to help me create this course:

Forecasting: Principles and Practice by Rob J. Hyndman and George Athanasapoulos - A very good book available for free that gives clear and concise explanations. Coding examples are in R.
+ (l)[https://otexts.com/fpp2/]


Time series forecasting - A tutorial on the official TensorFlow website that covers everything you need to know about applying deep learning for time series forecasting. A great resource!
+ (l)[https://www.tensorflow.org/tutorials/structured_data/time_series]

(Phophet Docs)[https://facebook.github.io/prophet/docs/quick_start.html#python-api]

## O que é Time Séries

Time Series é uma série de um determinado valor organizada/indexada por tempo. POssui 4 componentes:

+ Nível (level): A média desse valor na série
+ Tendencia (trend): o crescimento ou queda no valor no decorrer do tempo
+ sazionalidade (seasonality): comportamneto ciclico dos valores
+ ruido (noise): randomicidade da series

## Estatística Descretiva e inferencial

Descritiva
+ Objetivo de sumarizar os dados
+ visualizar as informações: histogramas e scatter plots

Inferencial
+ Usada para inferiri, deduzir, concluir algo sobre os dados, nao vamos mais análisala e sim tomar uma conclusao sobre eles que nã está explicita nos dados
+ Usamos Teste de hipotetes
  - hipotese ?  a ideia que quremos provar como verdadeira
    * ex: existe correlaçao linear entre o tempo e a concentraçao de CO2
  - hipotese nula ? o oposto dela
    * Nâo existe correlaçao linear entre o tempo e a concentraçao de CO2
  - Rodamos entao testes estatistico que, de acordo com o valor, se for maior/menor que um valor x podemos aceitar a nossa hipotese
+ Usamos tambem QQPlot - Quantile-Quantiel Plot
  - Serve para dizer se a distribuiçâo é ou nâo normal visualmente

Residuos
+ Diferença entre o valor predito e o valor real.  Tende a uma distribuiça normal

## Autocorrelation and Wite Noide

Corelaçâo mede o relacionamento entre duas variáveis.

AutoCorrelaçâo mede o relacionamento linear entre os valores no decorrer do tempo, ou seja, numa time series. 
+ Assim a autocorrelaçâo é algo coo: r1 é a correlaço entre y no tempo t, y(t) e y(t+1) (no futuro) ou com y(t-1) passado

## AutoCorrelation Function - ACF

Gráfico para mostrar a autocorrelaçâo,onde no eixo X fica o lag (o tempo passando) e no eixo y os coeficientes de autocorrelaçao.

Autocorrelaçâo varia de 0 à 1

Quando a autoCorrelaçâo for alta:
+ Vai começar alto e vai descer gradualmente a cada lag

## White Noide

WHite Noise é o nome da time seris onde nâo há autocorrelação. É onde a times series se compora como um processo stochastico randomico. Nesse caso, obviamente, a ACF nâo msotra nada de singificante
+ Nesse caso, o primeiro lag, **QUE SEMPRE É 1** é o única valor alto e o restante é tduo baixo. Isso acontece por que:
  1. O primeiro lag é a propria origem, o primeiro dado, que obviemante é ele mesmo e por isso tem valor 1.
  2. Agora, como é estochastico, os outros valores acabam nao tendo muita relaçâo com o primieo lag e nem o restante, ficando assim toda a ACF baixa

## Estacionairdade e DIferenciação

Estacionaridade é a propriedade da TIme Series de ela nao mudar muito com o tempo. É termédia e variancia constate, e covaricancia independente do tempo
+ Para acontecer isso, ela nao deve ter tencencia e nem ster sazionalidade
+ wHITE Noise são estacionárias


Diferenciaçâo: É a tranformaçâo de tranformar uma time series em estaicionário. Para fazre isso removemos a tendencia e estabilizamos a média
+ Tirar o logaritmoda tim series é uma boa forma de fazer isso (box-cox)
+ ou tambem fazer: t(0) = t(1) - t(0)

## Random Walk - Um modelo de uma Time Series

É um modelo de time sereis onde para um instate t é a soma de todos os outro t anteriores mais alugum ruido aleratprorio
+ No caso que vamos ver, o ruido será como uma nromal, de média 0 e variancia de 1

Lembrando, isso é um esquema de uma time series, ou seja, uma time series PODE SER ASISM, nao quer dizer que é um modelo para prever.


Obviamento, se um dando depende do outro mais ualguma coisa aleartorio pequena, há correlaçÃo e entao a tme series random walk nao é estácionária

## Moving Average - Forecast Model

É um modelo detime series que também já há uma soluçâo para forecat, é quando uma time series é na verdade: predizer um valor de time series usando os erros das previçôes passadas para a próxima previsão.

Nos referismo a ele como MA(q) model, onde q é a ordem.

Sendo t = tempo/lag t

xt = zt + o1*z(t-1) + o2*z(t-2) ....

Podemos usar o ACF para estimar o valor q da ordem. Após o lag 1, a autocorrelaçâo passa a nâo ser mais significante e entao podemos usar esse valor q.

## AutoREgressive Models

Usa uma combinaça linear dos valores passados para fazer previsoes. Autoregressivo pois é uma refressao nele mesmo

yt = constante + o1*y(t-1) + o2*y(t-2) + .. + epsilon('ruido aleartorio).

É um modelo flexivel que se encaixa em vários padroes de time series. 

Só pode ser suado para sśeries estácionarias

Nos referemios a modelos autoREgressivos como modelos AR(p) onde p é a ordem.

EM geral, sua ACF tem coisas estranhas no inicio de tal forma que fica complicado dizer se é u nao uma AR, entao , ao invez de só usarmo a ACF avmos usar a PACF.

A PACF serve para determinar a ordem de uma AR, pois ela filra aquilo que a ACF nao pega e nos msotra o q para a AR.

PACF: Encontra a correlaçao entre o valor presente e os residuos do lag anterior. Ou seja, encontra uma correlaçao nao explicavel na ACF.

### ADFUller test

A hipotese nula é que o dataset nao é estácionario.

Se você rodar o ADFuller test e pegar um P_Value menor que 0.05 entao podeos rejeitar a hipotese nula e assim assumir que a Série é estácionária

### ARMA

Combinaçao de AR(p) e MA(1) :: ARMA: Autoregressive moving average model, ARMA(p,q) 

Esse modelo é capaz de, pegar o random  noise (Moving average) e tambem a influencia do passao anterrior (autoregression).

Em um processo ARMA, tanto a ACF quanto a PACF ficam confusas e nâo servem para determinar a ordem da ARMA, de jeito nehum.

### ARIMA  

Combinaçao de AR(p), MA(q) e diferenciaççao :: ARIM(p,d,q):
p: ordme para autoregressao
d: grau de diferenciaçâo (numero de vezes que foi diferenciada)
q: orrde de moving average

Integraçâo é o oposto de diferenciação.

Como a ARMA nao tem como usarmos ACF e PACF para estimar os valores p e q, mas se um deles for 0 isso será bem mostrado já que torna o ACF ou PACF úteis

### SARIMA

Seasonal autoregressive integrated moving average model

Agora considera sazionalidade

Sarima é: Uma Arima que combina AR(p), MA(q) e diferenciação, adicionando agora a questão de sazionalidade

### AIC : Akaike Information Criterion

AIC é util para escolher p e q de AR(P) E ma(q).

Selecionamos os parametros que fornecem o manor AIC.

AIC não serve para selecionar o parametro 'd', pois ele muda toda a fórmula de cálculo. ENtâo, só podmeos fazer e comparar AIC num mesmo 'd'.

Ter baixo AIC nâo é garantia de modelo ótimo, mas é um bom critério apra escolher.

### SARIMAX

O X vem de Exogenus variabel. COm Sarimax adicionamos ao nosso modelo outra variável. Até agora previamos simplismente olhando o tempo, com SARIMAX adicioanmos outra variável.

SÓ DÁ PRA PREDIZER COM 1 VARIÁVEL. Sarimax não é uma forma de prever multivariate time series

## WorkFlow paara grar modelos de TS

1. PLotar os dados e identificar coisa estrnhas e o padrao dos dados
2. APlicar diferenciaçâo para remover tendencia e assi tornar a série estacionária
3. APlicar o testse de estaciponaridade: com ADF_Fuller. SE NÂO FOR ESTACIONÁRIA, APLIQUE DENOVO DIFERENCIAÇÃO
4. Usar ACF, e PCAF para estimar MAR e AR se possivel
5. Tentar diferentes combinaçoes para se obter o modelo de menor AIC
6. Avaliar os residuaos, ele devera seguir a distribuiçâo normla se for um bom modelo. Ljung-Box Test
7. Fazer predições

## Vector AutoRegressions

Até agora consideramos somente time series de uma única variavel. O valor e a data

Tmabem assumimos que há um relacionamento unidirecional entre o target e a feature: queremos dizer que a feature impcata no target mas nao o contrário.

É uma generalizaçâo do modelo AR(p) para modelos de prediçâo de um vetor de Time Series.

Cada time Series é modelada como se infleunciace umas as outras egualmente (???).

Matematicamente seria um sistems de equaçôes de time series.

Para usar VAR, todas as TS devem ser estacionárias

útil para prever mais de uma timeSeries num mesmo dataset: onde provavelmente uma timseSeries influencia na Outra e vice-versa.
