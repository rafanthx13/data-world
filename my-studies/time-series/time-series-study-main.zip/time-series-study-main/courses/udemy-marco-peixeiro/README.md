# Applied Time Series Analysis in Python

**Nâo fiz a parte de DeepLearning**

link:
https://www.udemy.com/course/applied-time-series-analysis-in-python/

outros links
+https://medium.com/@gisely.alves/s%C3%A9ries-temporais-parte-2-7162d24c5429

## Sumário

- Basics
  + O qu eé time series
  + Estatística descritiva e estatística inferencial
- Aprendizagem Estatisca
  + RandomWalk
  + Moving Average
  + AutoRegression
  + ARIMA, SARIMA, SARIMAX, VAR, VARMA, VARMAX
- Deep Learning
  + RNN e LSTM
  + CNN
- Projeto Final

## Ativar PyEnv

link: https://stackoverflow.com/questions/50391868/python-3-5-in-statsmodels-importerror-cannot-import-name-representation

source ~/name_me/bin/activate

deactivate
Use `pip list` to show all packages

Para saber onde está e assim deletar

`which python` vai indicar o diretorio, ai delete aele
