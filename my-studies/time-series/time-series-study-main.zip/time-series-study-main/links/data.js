		var named_links = `
			Analytics Vidhya
			https://www.analyticsvidhya.com/blog/category/time-series/
			Project
			https://www.analyticsvidhya.com/blog/2018/05/24-ultimate-data-science-projects-to-boost-your-knowledge-and-skills/
			Machine Learning Mastery
			https://machinelearningmastery.com/start-here/#timeseries
		`

            var random_links = `
			https://medium.com/ensina-ai/princ%C3%ADpios-b%C3%A1sicos-para-criar-previs%C3%B5es-de-s%C3%A9ries-temporais-e58c451a25b
			https://medium.com/ensina-ai/prevendo-pre%C3%A7os-para-5-dias-adiante-7ea5922c30ce
			https://www.analyticsvidhya.com/blog/2018/02/time-series-forecasting-methods/
		`

            var visited_links = `
			https://medium.com/data-hackers/series-temporais-parte-1-a0e75a512e72
			https://machinelearningmastery.com/time-series-forecasting-methods-in-python-cheat-sheet/
			https://medium.com/techbloghotmart/o-que-s%C3%A3o-s%C3%A9ries-temporais-e-como-aplicar-em-machine-learning-6ea5d94bec78
			https://medium.com/techbloghotmart/dicas-para-criar-um-modelo-de-previs%C3%A3o-de-s%C3%A9ries-temporais-d4bb2e32e148
			https://towardsdatascience.com/significance-of-acf-and-pacf-plots-in-time-series-analysis-2fa11a5d10a8
			https://towardsdatascience.com/the-complete-guide-to-time-series-analysis-and-forecasting-70d476bfe775
		`
            var tech_links = `
			https://facebook.github.io/prophet/
			https://people.duke.edu/~rnau/411home.htm
		`

            var techinical_links = `
			ACF PACF
			https://towardsdatascience.com/significance-of-acf-and-pacf-plots-in-time-series-analysis-2fa11a5d10a8
		`

            var quiz_links = `
			https://www.analyticsvidhya.com/blog/2017/04/40-questions-on-time-series-solution-skillpower-time-series-datafest-2017/
		`

			var project_links = `
			https://www.kaggle.com/sayakchakraborty/airquality
			https://datahack.analyticsvidhya.com/contest/genpact-machine-learning-hackathon-1
			https://datahack.analyticsvidhya.com/contest/practice-problem-time-series-2
			https://www.kaggle.com/PROPPG-PPG/hourly-weather-surface-brazil-southeast-region/
		`
