https://www.vooo.pro/insights/guia-completo-para-criar-time-series-com-codigo-em-python/

ou

https://www.analyticsvidhya.com/blog/2016/02/time-series-forecasting-codes-python/
