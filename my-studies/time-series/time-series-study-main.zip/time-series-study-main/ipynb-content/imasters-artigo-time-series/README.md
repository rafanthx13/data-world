https://imasters.com.br/data/series-temporais-e-componentes-aplicando-arima-para-forecast-em-dados-do-covid-19
