# Plotly-Dashboards-with-Dash
## Welcome to the course repo!
Do you want to learn how to create amazing dashboards with Python, Plotly, and
Dash?

Enroll in our course! Use the link below to get a 30-day trial at 95% off!
https://www.udemy.com/draft/1575562/?couponCode=GITHUB_DASHBOARDS
